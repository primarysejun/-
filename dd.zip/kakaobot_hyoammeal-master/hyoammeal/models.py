from django.db import models

# nothing here
