from django.apps import AppConfig


class HyoammealConfig(AppConfig):
    name = 'hyoammeal'
